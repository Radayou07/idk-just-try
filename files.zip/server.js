// ============================================
// BACKEND - server.js
// This is the "brain" of your website.
// It handles requests from the frontend,
// talks to the database, and sends back data.
// ============================================

const express = require("express");
const cors = require("cors");
const Database = require("better-sqlite3");

const app = express();
const PORT = 3000;

// ── MIDDLEWARE ────────────────────────────────
// Middleware runs on every request before your routes.
app.use(cors());               // Allow frontend (different port) to talk to backend
app.use(express.json());       // Parse JSON bodies from requests


// ── DATABASE SETUP ────────────────────────────
// We use SQLite — it's a simple file-based database.
// Great for learning and small projects!
const db = new Database("books.db");  // Creates a file called books.db

// Create our table if it doesn't exist yet
db.exec(`
  CREATE TABLE IF NOT EXISTS books (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    title     TEXT NOT NULL,
    author    TEXT NOT NULL,
    note      TEXT,
    rating    INTEGER,
    created_at TEXT DEFAULT (datetime('now'))
  )
`);

console.log("✅ Database connected: books.db");


// ── ROUTES (API Endpoints) ────────────────────
// Routes are URLs the frontend can "call".
// Frontend → calls a URL → backend runs code → returns data


// GET /books — Fetch ALL books from database
app.get("/books", (req, res) => {
  const books = db.prepare("SELECT * FROM books ORDER BY created_at DESC").all();
  res.json(books);  // Send books as JSON back to frontend
});


// POST /books — Save a NEW book to database
app.post("/books", (req, res) => {
  const { title, author, note, rating } = req.body;  // Data sent from frontend

  // Basic validation
  if (!title || !author) {
    return res.status(400).json({ error: "Title and author are required" });
  }

  const result = db.prepare(
    "INSERT INTO books (title, author, note, rating) VALUES (?, ?, ?, ?)"
  ).run(title, author, note, rating);

  // Send back the newly created book
  const newBook = db.prepare("SELECT * FROM books WHERE id = ?").get(result.lastInsertRowid);
  res.status(201).json(newBook);
});


// DELETE /books/:id — Delete a book by ID
app.delete("/books/:id", (req, res) => {
  const { id } = req.params;  // :id comes from the URL e.g. /books/3
  db.prepare("DELETE FROM books WHERE id = ?").run(id);
  res.json({ message: "Book deleted" });
});


// ── START SERVER ──────────────────────────────
app.listen(PORT, () => {
  console.log(`🚀 Backend running at http://localhost:${PORT}`);
  console.log(`   Try: http://localhost:${PORT}/books`);
});
